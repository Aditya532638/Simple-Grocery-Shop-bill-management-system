package jan11;

import java.util.Scanner;

public class Shop {

	int milk;
	int bread;
	int soap;
	int price1, price2, price3, total_price = 0;
	String m, b, s;

	Scanner sc = new Scanner(System.in);

	void milk_quantity() {

		System.out.print("\n\tIf you want milk pls type Yes/\tIf you Don't want milk pls type No: ");
		m = sc.next();

		if (m.equals("yes") || m.equals("Yes") || m.equals("YES")) {
			System.out.print("\tHow many Packets of milk you want:");
			milk = sc.nextInt();

			price1 = (milk * 35);

			System.out.println("\n\t" + milk + " Packet milk price is: " + price1);
		} else if (m.equals("No") || m.equals("NO") || m.equals("no")) {

			System.out.println("\tDon't want Milk!!!");

		} else {
			System.out.println("\tPlease Type yes/no only!!!");

		}

		System.out.println("\n============================================================\n");

	}

	void bread_quantity() {

		System.out.print("\tIf you want Bread pls type Yes/\tIf you Don't want Bread pls type No: ");
		b = sc.next();

		if (b.equals("yes") || b.equals("Yes") || b.equals("YES")) {
			System.out.print("\tHow many Packets of bread you want:");
			bread = sc.nextInt();

			price2 = (bread * 30);

			System.out.println("\n\t" + bread + " Bread Packet price:" + price2);
		}

		else if (b.equals("No") || b.equals("NO") || b.equals("no")) {

			System.out.println("\tDon't want Bread!!!");

		} else {
			System.out.println("\tPlease Type yes/no only!!!");

		}

		System.out.println("\n============================================================\n");

	}

	void soap_quantity() {

		System.out.print("\tIf you want Soap pls type Yes/\tIf you Don't want Soap pls type No: ");
		s = sc.next();

		if (s.equals("yes") || s.equals("Yes") || s.equals("YES")) {

			System.out.print("\tHow many Packets of soap you want:");
			soap = sc.nextInt();

			price3 = (soap * 20);

			System.out.println("\n\t" + soap + " Soap price:" + price3);
		}

		else if (s.equals("No") || s.equals("NO") || s.equals("no")) {

			System.out.println("\tDon't want Soap!!!");

		} else {
			System.out.println("\tPlease Type yes/no only!!!");

		}

		System.out.println("\n============================================================\n");

	}

	void totalPrice() {

		total_price = (price1 + price2 + price3);

		System.out.println("\tProducts\tQuantity\tPrice");
		System.out.println("\t Milk " + "\t\t (" + milk + ")\t\t " + price1);
		System.out.println("\t Bread " + "\t\t (" + bread + ")\t\t " + price2);
		System.out.println("\t Soap " + "\t\t (" + soap + ")\t\t " + price3);
		System.out.print("\t---------------------------------------------------------");

		System.out.println("\n\tTotal price of your products is:  " + total_price);

		System.out.println("\n\n\t\t\t THANK YOU FOR SHOPPING WITH US!...");

	}
public static void main(String[] args) {
		
		System.out.print("\t\t\t***WelCome to Our Shop***\n");
		Shop p=new Shop();
		
		p.milk_quantity();
		p.soap_quantity();
		p.bread_quantity();
		p.totalPrice();

	}

}
