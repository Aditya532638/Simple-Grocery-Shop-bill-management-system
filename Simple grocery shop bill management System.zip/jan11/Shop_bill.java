package jan11;

public class Shop_bill {

	public static void main(String[] args) {
		
		System.out.print("\t\t\t***WelCome to Our Shop***\n");
		Shop p=new Shop();
		
		p.milk_quantity();
		p.soap_quantity();
		p.bread_quantity();
		p.totalPrice();

	}

}
